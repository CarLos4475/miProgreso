import UIKit

let x = true
let y = false
let resultado = x || y
print(resultado)

let negando = !x

var igualIgual = x == y
igualIgual = x == x

var v1 = 7
var v2 = 8

let mayor = v2 > v1

v1 = 5
v2 = 5

let mayorIgual = v1 >= v2

//  ARREGLOS

var numeros1: [Int] = [1, 2, 3, 4]
var nombres1: [String] = ["Carlos", "Rafa", "Vite"]

//ACCESO

let numeros1_1 = numeros1[2]
let nombres1_1 = nombres1[0]

//MODIFICAR

numeros1[2] = 14
print(numeros1[2])
nombres1[1] = "Caballero"
print(nombres1[1])

//LONGITUD
let num_nombres1 = numeros1.count

//AGREGAR Y ELIMINAR

numeros1.append(5)
print(numeros1[4])
numeros1.remove(at: 3)
print(numeros1[3])

//ITERACION

/*for 0 in 15 {
    print(15)
}
*/

//ORDENAMIENTO

var numerosMal = [2, 5, 8, 1]
let numerosBien = numerosMal.sorted()
numerosMal.sort()

//CONDICIONALES

if v2 > 0 {
    print("POSITIVO")
}
else {
    print("NEGATIVO")
}

//ANIDADO

let temp = 25
if temp > 30{
    print("CALOR")
} else {
    if temp < 30 {
        print("FRIO")
    } else {
        print("NORMAL")
    }
        
}

//ELSE IF
if temp > 30 {
    print("CALOR")
} else if temp < 30 {
    print("FRIO")
} else {
    
}

//TERNARIO

let nmu3 = 7
let resultado2 = numeros1 > 5 ? "ES MAYOR QUE 5" : "NO ES MAYOR"

//SWITCH
let valorAEvaluar = 5
switch valorAEvakuar {
case 5:
    //
case 7:
    //
default:
    //
}


