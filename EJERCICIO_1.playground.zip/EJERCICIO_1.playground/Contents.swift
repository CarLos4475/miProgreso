import UIKit

// EJERCICIO 1:

let numero1 = 7
let numero2 = 11

let op1 = numero1 + numero2
let op2 = numero1 * numero2
let op3 = numero1 / numero2

let comp1 = numero1 < numero2
let comp2 = numero1 > numero2
let comp3 = numero1 != numero2

//EJERCICIO 2:

var arreglo1: [Int] = [3, 8, 5, 1, 0]
let numArreglo1 = arreglo1.count
let ordenArreglo1 = arreglo1.sorted()
print(ordenArreglo1)

arreglo1.append(10)
arreglo1.append(14)
print(arreglo1.sorted())

arreglo1.remove(at: 2)
print(arreglo1)

// EJERCICIO 3:

let a = 4
let b = 3

if a>b {
    print("A ES MAS GRANDE QUE B")
} else if b>a {
    print("B ES MAYOR QUE A")
} else {
    print("SON IGUALES")
}

//EJERCICIO 4:

let miEdad = 18
let tuEdad = miEdad > 21 ? "ERES MAYOR DE 21" : "NO ERES MAYOR"

//EJERCICIO 5:

let num1 = 3
let num2 = -4

if num1 > 0 {
    print(num1," ES POSITIVO")
} else if num1 < 0 {
    print(num1, " ES NEGATIVO")
} else {
    print(num1, "ES CERO")
}

if num2 > 0 {
    print(num2, " ES POSITIVO")
} else if num2 < 0 {
    print(num2, "ES NEGATIVO")
} else {
    print(num2, "ES CERO")
}
//EJERCICIO 6:

let clima = "Soleado"

switch clima {
case "Soleado":
    print("COMO EL CLIMA ES ",clima, " ENTONCES ES AGRADABLE")
case "Nublado":
    print("COMO EL CLIMA ES ",clima, " ENTONCES NO ES AGRADABLE")
case "Lloviendo":
    print("COMO EL CLIMA ES ",clima, " ENTONCES NO ES AGRADABLE")
default:
    print("INVALIDO")
}
