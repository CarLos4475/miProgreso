import UIKit

// EJERCICIOS

// 1.-


for i in 1 ... 10 {
    print ("Vamos en: \(i)")
}

var contador = 0

while contador <= 10 {
    print ("Vamos en: \(contador)")
    contador += 1
}

var contador1 = 0
repeat {
    print("Vamos en \(contador1)")
    contador1 += 1
} while contador1 < 11

// 2.-

for i in stride(from: 0, to: 21, by: 2){
    print("Numero par: \(i)")
}

// 3.-

var arreglo1 : [Int] = []
for i in stride(from: 2, to: 11, by: 2){
    arreglo1.append(i)
}
print(arreglo1)

// 4.-
var contador2 = 10
while contador2 >= 0 {
    print("Vamos en \(contador2)")
    contador2 -= 1
}

// 5.-
func imprimirMensaje1() {
    let nombre: String = "Carlos"
    print("Hola \(nombre)")
}
imprimirMensaje1()

//6.-
func imprimirMensaje2(nombre1: String, apellido1: String) -> String {
    let saludo = "Mi nombre es: \(nombre1), y mi apellido es: \(apellido1)"
    return saludo
}

let saludo1 = imprimirMensaje2(nombre1: "Carlos", apellido1: "Segura")
print(saludo1)
 
//7.-
func calcularaArea(base: Int, altura: Int) -> Int {
    let area = base * altura
    return area
}

let area1 = calcularaArea(base: 10, altura: 2)
print("El area de tu rectangulo es: \(area1)")

//8.-

struct estudiantes {
    var nombre: String
    var edad: Int
    var noCuenta: Int
    var plantel: String
    
    func matricula(){
        print("Nombre: \(nombre), Edad: \(edad), No.Cuenta: \(noCuenta), Plantel: \(plantel)")
    }
}

var estudiante1 = estudiantes(nombre: "Carlos", edad: 18, noCuenta: 321004475, plantel: "Acatlan")
estudiante1.matricula()

//9 y 10.-
var miSet: Set<Int> = [1,2,3,4,5,6,7,8,9,10]

print(<#T##items: Any...##Any#>)
