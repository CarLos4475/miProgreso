import UIKit

var saludo = "Hola mundo";

//Variables mutables

var edad = 25
edad = 26 // Se puede cambiar el valor

//Variables inmutables

let nombre = "Juan"
let pi = 3.1416 // No se puede cambiar el valor, de preferencía utilizar                let

//Nombrar variables

//Deben comenzar con una letra o un "_", si no sera error, tampoco debera tener caracteres esoeciales como !

let sistemaSistema = "MacOs" // Esta mal

let _5stema = "MacOs" // Esta bien

// Evitar usar palabras reservadas, evitar usar espacios, mejor usar "_" y mejor utilizar el formato camel case, empezar palabras con mayusculas:

let nombreUsuario = "Carlos"

// Tipos de datos: Se puede especificar, pero swift ya detecta los datos, por ejemplo numeros los detecta como enteros:

// ENTEROS:

let num1 = 300

//FLOTANTE:

let num2 = 3.1426

//BOOLEANOS:

let estaSoleado = true; // O false

//CADENA:

let s2aludo = "Hola soy Carlos"
let e2dad = "tengo 18 años"
let saludoCompleto = "/(saludo) /(edad)"

// MULTILINEA

let poema = """
Las rosas son rojas, el mar es azul, la azucar es dulce,
y asi eres tu.
"""
print(poema)

//TUPLAS, PERMITE AGRUPAR, DISTINTOS TIPOS

let persona: (String, Int) = (nombre: "Alicia", edad: 28)

//ARREGLOS, SOLO COSAS DEL MISMO TIPO

let numeros: [Int] = [1, 2, 3, 4, 5]

//DICCIONARIOS: COLECCIONES NO ORDENADAS DE PARES CLASE-VALOR

let puntiaciones: [String: Int] = ["Alicia": 95, "Bob": 80, "Eve": 72]


//OPCIONES: REPRESENTAN LA POSIBILIDAD QUE UN VALOR NO EXISTE

let usuario: String?

//TIPADO EXPLICITO: ESPECIFICAR LE TIPO DE DATO:

var variable1: Int = 18
let variable2: String = "hola"
let variable3: Float = 2.432556
let variable4: Double = 3.5

//EJERCICIOS

// 1.- CARLOS EMILIANO

// 2.-
/*
 CARLOS EMILIANO
 MAC
 18 AÑOS
 */

//3.-
let var1: String = "Carlos"
let var2: Int = 18
let var3: Bool = true

//4.-
let var4: String?
let var5: Int?
let var6: Bool?
let var7: String?

//5.-
let var8 = "CARLOS"
let var9 = 19
let var10 = true
let var11 = false

//6.-
let nombrePila: String = "Carlos Emiliano"
let apellido: String = "Segura Loera"
var edad2: Int = 18
